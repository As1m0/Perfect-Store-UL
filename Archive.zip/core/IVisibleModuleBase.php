<?php

interface IVisibleModuleBase extends IModuleBase
{
    function GetTemplate() : Template;
}
